package week13;

class Queue {
	private String[] elems;
	private int front;
	private int rear;
	private int count;
	private int queueSize;
	private int increment;
	
	public Queue() {
		front = 0;
		rear = 0;
		count = 0;
		queueSize = 50; //�ʱ� ť ũ��
		increment = 10; //�迭�� Ȯ�� ����
		elems = new String[queueSize];
	}
	
	//����, ���� �߰�
	public void enqueue(String x) {
		if(count == queueSize) queueFull();
		elems[rear] = x;
		rear = (rear + 1) % queueSize;
		count++;
	}
	
	//queue �� ������ �ø��� �޼ҵ�
	public void queueFull() {
		int oldsize = queueSize;
		
		queueSize += increment;
		String[] temp = new String[queueSize];
		
		for(int i = 0; i < count; i++) {
			temp[i] = elems[front];
			front = (front + 1) % oldsize;
		}
		
		elems = temp;
		front = 0;
		rear = count;
	}
	
	//���� �ϳ� ����
	public String dequeue() {
		if(isEmpty()) return null;
		
		String item = elems[front];
		front = (front + 1) % queueSize;
		count--;
		return item;
 	}
	
	//ť���� ���Ұ� ��ȯ
	public String peek() {
		if(isEmpty()) return null;
		else return elems[front];
	}
	
	//ť�� ������� üũ�ϴ� �޼ҵ�
	public boolean isEmpty() {
		return (count == 0);
	}
	
	//ť ��ü ���
	public void printAll() {
		System.out.print("[ ");
		
		if(isEmpty()) return;
		else {
			for(int i = front; i < rear; i++) {
				System.out.print(elems[i]);
				if((i+1) != rear) System.out.print(" | ");
			}
		}
		
		System.out.print(" ]");
	}
}

public class p1 {
	public static void main(String[] args) {
		Queue q = new Queue();

		System.out.println("is Empty : " + q.isEmpty());
		System.out.println("\n----------- enqueue -----------");
		q.enqueue("Kim");
		q.enqueue("Lee");
		q.enqueue("Ann");
		System.out.println("is Empty : " + q.isEmpty());
		q.printAll();
		
		System.out.println("\n\n----------- dequeue -----------");
		String dequeueValue = q.dequeue();
		q.printAll();
		System.out.println("\nDequeue Value : " + dequeueValue);
		
		System.out.println("\n----------- peek -----------");
		String p = q.peek();
		System.out.println("Peek : " + p);
	}
}
