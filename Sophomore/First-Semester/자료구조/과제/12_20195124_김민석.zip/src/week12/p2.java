package week12;

class Node {
	private String data;
	private Node link;
	
	public void setData(String data) { this.data = data; }
	public void setLink(Node link) { this.link = link; }
	public String getData() { return data; }
	public Node getLink() { return link; }
}

class LinkedStack {
	private Node top;
	
	public void push(String s) {
		Node newNode = new Node();
		
		newNode.setData(s);
		newNode.setLink(top);
		top = newNode;
	}
	
	public void pop() {
		if(top == null) return;
		else {
			System.out.println("���� ���� : " + top.getData());
			top = top.getLink();
		}
	}
	
	public void isEmpty() {
		if(top == null) System.out.println("����ֽ��ϴ�.");
		else System.out.println("������� �ʽ��ϴ�.");
	}
}

public class p2 {
	public static void main(String[] args) {
		LinkedStack ls = new LinkedStack();
		String[] member = { "Kim", "Ann", "Park", "Daniel", "Gwang" };
		
		ls.isEmpty();
		System.out.println("=====================");
		
		for(int i = 0; i < member.length; i++) {
			System.out.println("Push : " + member[i]);
			ls.push(member[i]);
		}
		System.out.println("=====================");
		
		ls.isEmpty();
		System.out.println("=====================");
		
		ls.pop();
		ls.pop();
	}
}
