package week02;

public class tmp {
	public static void main(String[] args) {
		int[] value = { 4, 2, 1, 7, 8, 9, 5 };
		int a = 0;
		
		System.out.println("�迭 ���� ��");
		while(a != value.length) {
			System.out.println(value[a] + " ");
			a++;
		}
		
		System.out.println("\n�迭 ���� ��");
		bubble(value);
	}
	
	public static void bubble(int[] value) {
		for(int j = value.length-1; j >= 0; j--) {
			for(int i =0; i < j; i++) {
				if(value[i] > value[i+1]) {
					int temp = value[i];
					value[i] = value[i+1];
					value[i+1] = temp;
				}
			}
		}
		
		int a = 0;
		while(a != value.length) {
			System.out.println(value[a] + " ");
			a++;
		}
	}
}
