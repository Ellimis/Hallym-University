package week07;

class Term {
	// coef �� ���, exp �� ����
	private int coef;
	private int exp;
	
	public Term(int coef, int exp) {
		this.coef = coef;
		this.exp = exp;
	}
	public int getCoef() { return coef; }
	public int getExp() { return exp; }
}

class Polynomial2 {
	private Term[] items;
	private static final int MAX = 10;
	private int noOfTerms;
	
	public Polynomial2() {
		noOfTerms = 0;
		items = new Term[MAX];
	}
	
	// items �� ����ִ��� Ȯ��
	public boolean ispZero() {
		if(noOfTerms == 0) return true;
		else return false;
	}
	
	// ���� ���׽��� �ְ������� ���� ��ȯ..?
	public int maxExp() {
		return items[0].getExp();
	}
	
	public void addTerm(int c, int e) {
		if(noOfTerms != 0) {
			for(int i = 0; i < noOfTerms; i++) {
				// ���� �������� ������ ������ i ��°�� �ִ� ������ �������� Ŭ �� �ְ� �ڷ� ��ĭ�� �б� 
				if(e > items[i].getExp()) {
					for (int j = noOfTerms; j > i; j--) {
						items[j] = items[j - 1];
					}
					items[i] = new Term(c, e);
				} else items[noOfTerms] = new Term(c, e);
			}
		} else items[0] = new Term(c, e);
		
		noOfTerms++;
	}
	
	public void delTerm(int e) {
		for(int i = 0; i < noOfTerms; i++) {
			if(e == items[i].getExp()) {
				for (int j = i; j < noOfTerms - 1; j++) {
					items[j] = items[j + 1];
				}
			}
		}
		noOfTerms--;
	}
	
	// ������ e �� �ε����� ���� �ε��� ��ȣ ��ȯ..?
	public int findNextIndex(int e) {
		for(int i = 0; i < noOfTerms; i++) {
			if(items[i].getExp() == e) {
				return (i+1);
			}
		}
		return -1;
	}
	
	// ������ e �� �ε��� ��ȣ ��ȯ
	public int findIndex(int e) {
		for(int i = 0; i < noOfTerms; i++) {
			if(items[i].getExp() == e) {
				return i;
			}
		}
		return -1;
	}

	// �� ���׽��� �����ִ� �޼ҵ�
	public Polynomial2 polyAdd(Polynomial2 p) {
		Polynomial2 r = new Polynomial2();
		int tp = 0;
		int pp = 0;
		
		while(tp < this.noOfTerms && pp < p.noOfTerms) {
			if(this.items[tp].getExp() == p.items[pp].getExp()) {
				r.addTerm(this.items[tp].getCoef() + p.items[pp].getCoef(), p.items[pp].getExp());
				tp++;
				pp++;
			} else if(this.items[tp].getExp() < p.items[pp].getExp()) {
				r.addTerm(p.items[pp].getCoef(), p.items[pp].getExp());
				pp++;
			} else {
				r.addTerm(this.items[tp].getCoef(), this.items[tp].getExp());
				tp++;
			}
		}
		
		while(tp < this.noOfTerms) {
			r.addTerm(this.items[tp].getCoef(), this.items[tp].getExp());
			tp++;
		}
		
		while(pp < p.noOfTerms) {
			r.addTerm(p.items[pp].getCoef(), p.items[pp].getExp());
			pp++;
		}
		
		return r;
	}
	
	// �� ���׽��� �����ִ� �޼ҵ�
	public Polynomial2 polyMult(Polynomial2 q) {
		Polynomial2 r = new Polynomial2();
		
		for(int i = 0; i < this.noOfTerms; i++) {
			Polynomial2 t = new Polynomial2();
			int coef, exp;
			
			for(int qq = 0; qq < q.noOfTerms; qq++) {
				coef = this.items[i].getCoef() * q.items[qq].getCoef();
				exp = this.items[i].getExp() + q.items[qq].getExp();
				t.addTerm(coef, exp);
			}
			r = r.polyAdd(t);
		}
		
		return r;
	}
	
	// ���
	public void print() {
		String str = "";
		for(int i = 0; i < this.noOfTerms; i++)
			str += this.items[i].getCoef() + "[" + this.items[i].getExp() + "] + ";
		
		System.out.println(str.substring(0, str.length()-2));
	}
}
public class p2_20195124 {
	public static void main(String[] args) {
		Polynomial2 p = new Polynomial2();
		p.addTerm(6, 4);
		p.addTerm(2, 3);
		p.addTerm(3, 0);
		p.print();
		
		Polynomial2 q = new Polynomial2();
		q.addTerm(2, 4);
		q.addTerm(4, 2);
		q.addTerm(2, 1);
		q.print();
		
		Polynomial2 r = p.polyAdd(q);
		r.print();

		r = p.polyMult(q);
		r.print();
	}
}
