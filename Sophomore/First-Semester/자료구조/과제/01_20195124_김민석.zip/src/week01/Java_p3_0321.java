package week01;

import java.util.Scanner;

public class Java_p3_0321 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int sum = 0, n;
		
		System.out.print("���ϴ� ���ڸ� �Է����ּ��� : ");
		n = sc.nextInt();
		
		for(int i = 1; i <= n; i++) {
			if(i%3 != 0) {
				System.out.println(i);
				sum += i;
			}
		}
		
		System.out.println("Total : " + sum);
	}
}
