package week01;

public class Java_p2_0321 {
	public static void main(String[] args) {
		int i;
		
		System.out.println("----------- for �� -----------");
		for(i = 1; i <= 100; i++) {
			System.out.println(i);
		}
		
		System.out.println("----------- while �� -----------");
		i = 1;
		while(i <= 100) {
			System.out.printf("%3d\n", i); //C��� ó�� ���
			i++;
		}
		
		System.out.println("----------- for ��(if�� �߰�) -----------");
		for(i = 1; i <= 100; i++) {
			if(i%2 == 0) System.out.println(i);
		}
		
		System.out.println("----------- while ��(if�� �߰�) -----------");
		i = 1;
		while(i <= 100) {
			if(i%2 != 0) System.out.printf("%3d\n", i);
			i++;
		}
	}
}
