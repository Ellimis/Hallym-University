package week03;

public class ProfessorList {
	private Professor[] pf;
	private int number;
	
	public ProfessorList() {
		pf = new Professor[20];
		number = 0;
	}
	
	public ProfessorList(int num) {
		pf = new Professor[num];
		number = 0;
	}
	
	public void addProfessor(Professor pf) {
		this.pf[number] = pf;
		number++;
	}
	
	public Professor getById(int id) {
		for(int i = 0; i < number; i++) {
			if(pf[i].getId() == id)
				return pf[i];
		}
		return null;
	}
	
	public Professor getByName(String name) {
		for(int i = 0; i < number; i++) {
			if(pf[i].getName().equals(name))
				return pf[i];
		}
		return null;
	}
	
	public Professor professorAt(int idx) {
		return pf[idx]; // 2 �� ����°�� �ִ� ������, 0 �̸� ù������ �ִ� ������ ���� return
	}
	
	public void print() {
		for(int i = 0; i < number; i++) {
			System.out.println(pf[i]);
		}
	}
}
