package week03;

public class Student {
	private int id;
	private String name;
	private int score;
	private Professor advisor;

	public Student(int id, String name, int score) {
		this.id = id;
		this.name = name;
		this.score = score;
	}

	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public int getScore() {
		return score;
	}

	public void setAdvisor(Professor advisor) {
		this.advisor = advisor;
	}

	public Professor getAdvisor() {
		return advisor;
	}

	public void changeScore(int score) {
		this.score = score;
	}

	public String toString() {
		return "(Student) Id : " + id + ", Name : " + name + ", Score : " + score;
	}
}
