package week03;

public class StudentList {
	private Student[] std;
	private int number;

	public StudentList() {
		std = new Student[20];
		number = 0;
	}

	public StudentList(int num) {
		std = new Student[num];
		number = 0;
	}

	public void addStudent(Student std) {
		this.std[number] = std;
		number++;
	}

	public Student getById(int id) {
		for (int i = 0; i < number; i++) {
			if (std[i].getId() == id)
				return std[i];
		}
		return null;
	}

	public Student getByName(String name) {
		for (int i = 0; i < number; i++) {
			if (std[i].getName().equals(name))
				return std[i];
		}
		return null;
	}

	public Student studentAt(int idx) {
		return std[idx]; // 2 �� ����°�� �ִ� �л�, 0 �̸� ù������ �ִ� �л� ���� return
	}

	public void sortByScore() { // ��������
		int i, j, n;
		for (i = 0; i < number - 1; i++) {
			n = i;
			for (j = i + 1; j < number; j++) {
				if (std[n].getScore() <= std[j].getScore())
					n = j;
			}
			Student temp = std[n];
			std[n] = std[i];
			std[i] = temp;
		}
	}

	public void sortById() { // ��������
		int i, j, n;
		for (i = 0; i < number - 1; i++) {
			n = i;
			for (j = i + 1; j < number; j++) {
				if (std[n].getId() >= std[j].getId())
					n = j;
			}
			Student temp = std[n];
			std[n] = std[i];
			std[i] = temp;
		}
	}

	public void reverse() { //���� ���� ����
		for(int i=0; i< number/2; i++){ 
			Student temp = std[i];
			std[i] = std[number -i -1];
			std[number -i -1] = temp; 
		}
	}

	public double Average() { //�л��� ���
		double hap = 0.0;
		for (int i = 0; i < number; i++) {
			hap += std[i].getScore();
		}

		return hap / number;
	}
	
	public void print() { //�л� ���� ��� ���
		for(int i = 0; i < number; i++) {
			System.out.println(std[i]);
		}
	}
}
