package week06;

public class p1_20195124 {
	public static void main(String[] args) {
		int a[] = { 1, 2, 3, 4, 5 };
		int b[];
		
		b = a;
		
		System.out.println("�迭 a ���.");
		for(int i = 0; i < a.length; i++) {
			System.out.println("a[" + i + "] : " + a[i]);
		}
		
		b[4] += 10;
		System.out.println("\nb[4]�� �� ��ȭ �� �迭 a ���.");
		for(int i = 0; i < a.length; i++) {
			System.out.println("a[" + i + "] : " + a[i]);
		}
		
		System.out.println("==============================");
		
		b = (int[]) a.clone(); //�迭 ����
		
		System.out.println("�迭 a ���.");
		for(int i = 0; i < a.length; i++) {
			System.out.println("a[" + i + "] : " + a[i]);
		}
		
		b[4] += 10;
		System.out.println("\nb[4]�� �� ��ȭ �� �迭 a ���.");
		for(int i = 0; i < a.length; i++) {
			System.out.println("a[" + i + "] : " + a[i]);
		}
	}
}
