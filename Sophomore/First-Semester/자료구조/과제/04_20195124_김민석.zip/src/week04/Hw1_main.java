package week04;

public class Hw1_main {
	public static void main(String[] args) {
		int[] a = { 1, 6, 13, 41, 45, 68, 70, 74, 81, 100 };
		System.out.println(search(a, 81));
	}
	
	public static int binarySearch(int a[], int key, int left, int right) {
		int mid;
		if(left <= right) {
			mid = (left + right) / 2;
			if(key == a[mid]) return mid;
			else if(key < a[mid]) return binarySearch(a, key, left, mid-1);
			else return binarySearch(a, key, mid+1, right);
		}
		else return -1;
	}
	
	public static int search(int a[], int key) {
		return binarySearch(a, key, 0, a.length-1);
	}
}
