package week04;

public class Hw2_main {
	public static void main(String[] args) {
		System.out.println(fibonachi(7));
	}
	
	public static int fibonachi(int n) {
		if(n <= 0) return 0;
		else if(n == 1) return 1;
		else {
			return (fibonachi(n-1) + fibonachi(n-2));
		}
	}
}
