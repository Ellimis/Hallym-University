package week04;

public class P2_factorial {
	public static void main(String[] args) {
		System.out.println(factorial(10));
	}
	
	public static int factorial(int n) {
		int temp = 1;
		for(int i = 1; i <= n; i++) {
			temp = temp*i;
		}
		
		return temp;
	}
}
