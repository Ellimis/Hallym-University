package week07;

class Term {
	// coef �� ���, exp �� ����
	private int coef;
	private int exp;
	
	public Term(int coef, int exp) {
		this.coef = coef;
		this.exp = exp;
	}
	public int getCoef() { return coef; }
	public int getExp() { return exp; }
}

class Polynomial2 {
	private Term[] items;
	private static final int MAX = 10;
	private int noOfTerms;
	
	public Polynomial2() {
		noOfTerms = 0;
		items = new Term[MAX];
	}
	
	// items �� ����ִ��� Ȯ��
	public boolean ispZero() {
		if(noOfTerms == 0) return true;
		else return false;
	}
	
	// ���� ���׽��� �ְ������� ���� ��ȯ
	public int maxExp() {
		return items[0].getExp();
	}
	
	public int coef(int e) {
		return items[e].getCoef();
	}
	
	public boolean addTerm(int c, int e) {
		//if(coef(e) != 0) return false;
		
		Term n = new Term(c, e);
		int index = findNextIndex(e);
		
		for(int i = noOfTerms; i > index; i--) 
			items[i] = items[i-1];
		
		items[index] = n;
		noOfTerms++;
		return true;
	}
	
	public void delTerm(int e) {
		for(int i = 0; i < noOfTerms; i++) {
			if(e == items[i].getExp()) {
				for (int j = i; j < noOfTerms - 1; j++) {
					items[j] = items[j + 1];
				}
			}
		}
		noOfTerms--;
	}
	
	public Polynomial2 sMult(int c, int e) {
		Polynomial2 p = new Polynomial2();
		int exp, coef;
		
		for(int i = 0; i < noOfTerms; i++) {
			exp = items[i].getExp() + e;
			coef = items[i].getCoef() * c;
			p.items[i] = new Term(coef, exp);
		}
		
		p.noOfTerms = noOfTerms;
		return p;
	}
	
	public Polynomial2 polyMult(Polynomial2 p) {
		Polynomial2 r = new Polynomial2();
		
		for(int i = 0; i < p.noOfTerms; i++) {
			Polynomial2 t = sMult(p.items[i].getCoef(), p.items[i].getExp());
			r = r.polyAdd(t);
		}
		
		return r;
	}
	
	// �� ���׽��� �����ִ� �޼ҵ�
	public Polynomial2 polyAdd(Polynomial2 p) {
		Polynomial2 r = new Polynomial2();
		int tp = 0;
		int pp = 0;
		
		while(tp < this.noOfTerms && pp < p.noOfTerms) {
			if(this.items[tp].getExp() == p.items[pp].getExp()) {
				r.addTerm(this.items[tp].getCoef() + p.items[pp].getCoef(), p.items[pp].getExp());
				tp++;
				pp++;
			} else if(this.items[tp].getExp() < p.items[pp].getExp()) {
				r.addTerm(p.items[pp].getCoef(), p.items[pp].getExp());
				pp++;
			} else {
				r.addTerm(this.items[tp].getCoef(), this.items[tp].getExp());
				tp++;
			}
		}
		
		while(tp < this.noOfTerms) {
			r.addTerm(this.items[tp].getCoef(), this.items[tp].getExp());
			tp++;
		}
		
		while(pp < p.noOfTerms) {
			r.addTerm(p.items[pp].getCoef(), p.items[pp].getExp());
			pp++;
		}
		
		return r;
	}
	
	private int findNextIndex(int e) {
		for(int i = 0; i < noOfTerms; i++) {
			if(items[i].getExp() == e) return -1;
			if(items[i].getExp() < e) return i;
		}
		
		return noOfTerms;
	}

	public void print() {
		String str = "";
		
		for(int i = 0; i < this.noOfTerms; i++) {
			if(this.items[i].getCoef() != 0) {
				str += this.items[i].getCoef();
				if(this.items[i].getExp() != 0) 
					str += "x^" + this.items[i].getExp() + " + ";
			}
		}
		
		int plus = str.length()-2;
		
		if(str.charAt(plus) == '+') {
			System.out.println(str.substring(0, plus));
		} else System.out.println(str);
	}
}

public class p2_20195124 {
	public static void main(String[] args) {
		Polynomial2 p = new Polynomial2();
		
		p.addTerm(6, 4);
		p.addTerm(2, 3);
		p.addTerm(3, 0);
		p.print();
		
		Polynomial2 q = new Polynomial2();
		q.addTerm(2, 4);
		q.addTerm(4, 2);
		q.addTerm(2, 1);
		q.print();
		
		Polynomial2 r = p.polyAdd(q);
		r.print();

		r = p.polyMult(q);
		r.print();
	}
}
