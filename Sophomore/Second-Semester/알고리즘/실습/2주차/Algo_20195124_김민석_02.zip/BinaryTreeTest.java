
public class BinaryTreeTest {
	public static void main(String[] args) {
		BinaryTree root;
		BinaryTree leftTemp;
		BinaryTree rightTemp;
		
		BinaryTree leftSubRoot;
		BinaryTree rightSubRoot;
		
		BinaryTree empty = new BinaryTree();
		
		// left side
		leftTemp = new BinaryTree(empty, 'A', empty);
		rightTemp = new BinaryTree(empty, 'B', empty);
		leftSubRoot = new BinaryTree(leftTemp, '+', rightTemp);
		
		// right side
		leftTemp = new BinaryTree(empty, 'C', empty);
		rightTemp = new BinaryTree(empty, 'D', empty);
		rightSubRoot = new BinaryTree(leftTemp, '/', rightTemp);
		
		// Tree
		root = new BinaryTree(leftSubRoot, '*', rightSubRoot);
		
		System.out.println("===== root =====");
		root.show();
		
		System.out.println("===== root's right sub tree =====");
		root.rightSubTree().show();
		
		System.out.println("==== root's left sub tree =====");
		root.leftSubTree().show();
	}
}
