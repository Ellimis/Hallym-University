
public class sortMain {
	public static void main(String[] args) {
		Sort s = new Sort();
		int[] arr1 = { 8, 1, 23, 15, 31, 2, 26, 12 };
		int[] merge = s.mergeSort(arr1);
		
		System.out.println("Merge Sort : ");
		
		for(int i = 0; i < merge.length; i++) {
			System.out.print(merge[i] + " ");
		}
		System.out.println();
		
		int[] arr2 = { 3, 1, 5, 4, 9, 7, 8 };
		int[] quick = s.quickSort(arr2);
		
		System.out.println("Quick sort : ");
		
		for(int i = 0; i < quick.length; i++) {
			System.out.print(quick[i] + " ");
		}
		System.out.println();
	}
}
