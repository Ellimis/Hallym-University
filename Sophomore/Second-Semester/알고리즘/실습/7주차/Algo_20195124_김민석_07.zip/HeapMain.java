
public class HeapMain {
	public static void main(String[] args) {
		System.out.println("== Make Heap ==");
		
		int[] tree = { 0, 20, 40, 50, 70, 30, 100, 80, 10, 90, 60 };
		Heap nh = new Heap(tree);
		
		nh.makeTreeHeap();
		nh.show();
	}
}
