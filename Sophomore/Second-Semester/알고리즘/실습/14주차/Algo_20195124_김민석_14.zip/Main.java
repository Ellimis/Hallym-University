
public class Main {
	public static void main(String[] args) {
		HeapSort s = new HeapSort();
		int[] a = { 0, 20, 40, 50, 70, 30, 100, 80, 10, 90, 60 };
		int[] heap = s.heapSort(a);
		
		System.out.println("Heap sort: ");
		
		for(int i = 0; i < heap.length; i++) {
			System.out.print(heap[i] + " ");
		}
		System.out.println();
	}
}
