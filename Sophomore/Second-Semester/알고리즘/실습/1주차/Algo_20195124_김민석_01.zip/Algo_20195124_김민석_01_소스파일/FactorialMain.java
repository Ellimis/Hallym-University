import java.util.Scanner;

public class FactorialMain {
	public static void main(String[] args) {
		int num;
		Scanner input = new Scanner(System.in);
		
		System.out.print("input : ");
		num = input.nextInt();
		
		System.out.println("loop factorial("+ num +") : " + factorial_loop(num));
		System.out.println("recursion factorial("+ num +") : " + factorial_recursion(num));
	}
	
	private static int factorial_loop(int n) {
		int sum = 1;
		for(int i = 1; i <= n; i++) {
			sum *= i;
		}
		
		return sum;
	}
	
	private static int factorial_recursion(int n) {
		if(n <= 1)
			return 1;
		else 
			return n*factorial_recursion(n-1);
	}
}
