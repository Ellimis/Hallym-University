public class List {
	private Object ArrayList[] = new Object[100];
	private int size = 0;
	
	// List 마지막에 새로운 값 추가, 마지막 추가이기 문에 추가적인 index 변경 작업 필요 X
	public void addLast(Object data) {
		ArrayList[size] = data;
		size++;
	}
	
	// 특정 인덱스에 추가
	public void add(int index, Object data) {
		if(index > size) {
			System.out.println("List보다 큰 인덱스 입력하여 추가할 수 없습니다.");
			return;
		}
		
		for(int i = size - 1; i >= index; i--) {
			ArrayList[i+1] = ArrayList[i];
		}
		
		ArrayList[index] = data;
		size++;
	}
	
	// 특정 인덱스 제거
	public void delete(int index) {
		if(index> size-1 || index< 0) {
			System.out.println("잘못된 인덱스가 입력되었습니다.");
			return;
		}
		
		for(int i = index+1; i < size; i++) {
			ArrayList[i-1] = ArrayList[i];
		}
		
		ArrayList[size-1] = null;
		size--;
	}
	
	// 리스트의 모든 값을 출력하는 메소드
	public void showList() {
		int i;
		for(i = 0; i < 20; i++) {
			System.out.print("=");
		}
		System.out.println();
		
		for(i = 0; i < size; i++) {
			System.out.println("Array List ["+ i + "] : " + ArrayList[i]);
		}
		
		for(i = 0; i < 20; i++) {
			System.out.print("=");
		}
		System.out.println();
	}
}
