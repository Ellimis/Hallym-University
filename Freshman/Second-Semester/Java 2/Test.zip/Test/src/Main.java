
public class Main {

	public static void main(String[] args) {
		
		Polygon poly = new Polygon();
		poly.DrawPolygon();
		System.out.println();
		
		Rectangle rect = new Rectangle();
		rect.DrawPolygon();
		System.out.println();
		
		Triangle tri = new Triangle();
		tri.DrawPolygon();

	}

}
