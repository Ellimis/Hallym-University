public class Lion extends Animal {
	private int legs = 4;
	void roar() {
		System.out.println("roar()�� ȣ�� ��");
	}
}
