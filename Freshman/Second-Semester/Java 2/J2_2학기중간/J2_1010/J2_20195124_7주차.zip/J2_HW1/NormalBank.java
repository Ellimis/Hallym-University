public class NormalBank {
	public double getInterestRate() {
		return 5.0;
	}
}
