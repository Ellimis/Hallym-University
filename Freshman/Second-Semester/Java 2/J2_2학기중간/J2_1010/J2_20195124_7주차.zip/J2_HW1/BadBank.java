public class BadBank extends Bank {
	public double getInterestRate() {
		return 10.0;
	}
}
