public class GoodBank {
	public double getInterestRate() {
		return 3.0;
	}
}
