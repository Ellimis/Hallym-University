public class Bank {
	public double getInterestRate() {
		return 0.0;
	}
}
