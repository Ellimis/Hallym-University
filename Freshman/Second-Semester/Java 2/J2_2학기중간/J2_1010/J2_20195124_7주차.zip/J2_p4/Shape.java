public class Shape {
	private int x;
	private int y;
	
	public Shape(int x, int y) {
		System.out.println("Shape()");
		this.x = x;
		this.y = y;
	}
}
